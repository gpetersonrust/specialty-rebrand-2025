class SpecialtyDropdown {
  constructor(sourceMenuSelector, customDropdownContainerSelector) {
    // 1. Source Menu (where the data comes from)
    this.sourceMenu = document.querySelector(sourceMenuSelector);

    // 2. Target Custom Dropdown Container
    this.container = document.querySelector(customDropdownContainerSelector);

  

    if (!this.sourceMenu) {
      console.error(`SpecialtyDropdown: Source menu "${sourceMenuSelector}" not found.`);
      return;
    }
    if (!this.container) {
      console.error(`SpecialtyDropdown: Custom dropdown container "${customDropdownContainerSelector}" not found.`);
      return;
    }

    // 3. Elements within the Custom Dropdown Container
    this.elements = {
      wrapper: this.container.querySelector('#specialty-filter-wrapper'),
      trigger: this.container.querySelector('#specialty-trigger'),
      arrow: this.container.querySelector('#specialty-arrow-down'),
      menu: this.container.querySelector('#specialty-menu'),
      input: this.container.querySelector('.quick-filter-input'),
      optionsList: this.container.querySelector('#specialty-options'),
      // Note: allOptions and mainOptions will be populated AFTER generating them
      allOptions: null,
      mainOptions: null,
    };

    // Basic check for essential custom dropdown elements
    if (!this.elements.trigger || !this.elements.menu || !this.elements.optionsList) {
      console.error("SpecialtyDropdown: Could not find essential custom dropdown elements (trigger, menu, optionsList).");
      return;
    }

    this.selectedFilter = '.'; // Default filter value ('All Specialties')
    this.init();
  }

  init() {

    // Add mouseout event listener to container
    this.container.addEventListener('mouseleave', () => {
      this.toggleDropdown(false);
      console.log('mouse left');
      
    });
    // 1. Clear any existing dynamic options (keep "All Specialties")
    const allSpecialtiesLi = this.elements.optionsList.querySelector('.all-specialties');
    this.elements.optionsList.innerHTML = ''; // Clear previous
    if (allSpecialtiesLi) {
        this.elements.optionsList.appendChild(allSpecialtiesLi); // Put "All" back
    } else {
        console.warn("SpecialtyDropdown: Could not find the static 'All Specialties' list item to preserve it.");
        // Optionally, recreate it if missing:
        // const defaultLi = document.createElement('li');
        // defaultLi.className = 'specialty-option all-specialties';
        // defaultLi.setAttribute('data-filter', '.');
        // defaultLi.textContent = 'All Specialties';
        // this.elements.optionsList.appendChild(defaultLi);
    }


    // 2. Populate the custom dropdown from the source menu
    this.populateCustomDropdown();

    // 3. Re-query options now that they've been added
    this.elements.allOptions = this.container.querySelectorAll('#specialty-options li');
    this.elements.mainOptions = this.container.querySelectorAll('.specialty-option'); // Top-level only

    // 4. Add event listeners for interaction
    this.addEventListeners();

    // 5. Set initial state
    this.elements.menu.classList.add('hidden');
  }

  // --- Logic from original script, adapted ---
  getSpecialtyFromHref(href) {
    if (!href) return null;
    try {
      // Handle URLs relative to the current page or absolute URLs
      const url = new URL(href, window.location.origin);
      return url.searchParams.get("specialty") || null;
    } catch (e) {
      console.error(`Error parsing URL: ${href}`, e);
      return null;
    }
  }

  /**
   * Finds the "Specialties" list item in the source menu and populates
   * the custom dropdown's options list based on its children.
   */
  populateCustomDropdown() {
    // Find the specific "Specialties" top-level item in the source menu
    // Option 1: Using ID (if stable)
    // const specialtiesTopLevelItem = this.sourceMenu.querySelector('#menu-item-7538');
    // Option 2: Searching by text (more robust if ID changes)
    let specialtiesTopLevelItem = null;
    this.sourceMenu.querySelectorAll(':scope > li.menu-item').forEach(item => {
        const anchorText = item.querySelector(':scope > a .x-anchor-text-primary');
        if (anchorText && anchorText.textContent.trim().toLowerCase() === 'specialties') {
            specialtiesTopLevelItem = item;
        }
    });


    if (!specialtiesTopLevelItem) {
        console.error("SpecialtyDropdown: Could not find 'Specialties' section in the source menu.");
        return;
    }

    // Get the submenu directly under the "Specialties" item
    const specialtiesSubMenu = specialtiesTopLevelItem.querySelector(':scope > .sub-menu');
    if (!specialtiesSubMenu) {
        console.error("SpecialtyDropdown: 'Specialties' section found, but it has no submenu.");
        return;
    }

    // Iterate through the direct children (main specialties) of the "Specialties" submenu
    specialtiesSubMenu.querySelectorAll(':scope > li.menu-item').forEach(parentItem => {
      const parentAnchor = parentItem.querySelector(':scope > a');
      const parentTextEl = parentAnchor?.querySelector('.x-anchor-text-primary');
      const parentLabel = parentTextEl?.textContent.trim() || null;
      const parentHref = parentAnchor?.getAttribute('href');
      // Get the slug. If href is '#', maybe use the label to generate a slug?
      let parentSlug = this.getSpecialtyFromHref(parentHref);
      if (!parentSlug && parentLabel) {
         // Simple slug generation if href is missing or has no specialty param
         parentSlug = parentLabel.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '');
         console.warn(`Generated slug "${parentSlug}" for "${parentLabel}" as no specialty param was found in href.`);
      }


      // Check for a nested submenu (sub-specialties)
      const childMenu = parentItem.querySelector(':scope > .sub-menu');

      if (!parentLabel || !parentSlug) {
          console.warn("Skipping menu item - missing label or unable to determine slug:", parentItem);
          return; // Skip if we don't have essential info
      }

      const parentLi = document.createElement('li');
      // Sanitize slug for use as a class name (basic example)
      const slugClass = parentSlug.replace(/[^a-zA-Z0-9-_]/g, '');
      parentLi.className = `specialty-option ${slugClass}`; // Add slug as class
      parentLi.setAttribute('data-filter', `.${parentSlug}`); // Use raw slug for filter

      // Use createTextNode to avoid issues if label contains HTML-like chars
      parentLi.appendChild(document.createTextNode(parentLabel));


      if (childMenu) {
        // This is a parent specialty with sub-specialties
        const subList = document.createElement('ul');
        subList.className = 'subspecialty-list';

        childMenu.querySelectorAll(':scope > li.menu-item').forEach(childItem => {
          const childAnchor = childItem.querySelector(':scope > a');
          const childTextEl = childAnchor?.querySelector('.x-anchor-text-primary');
          const childLabel = childTextEl?.textContent.trim();
          const childHref = childAnchor?.getAttribute('href');
          const childSlug = this.getSpecialtyFromHref(childHref);

          if (childLabel && childSlug) {
            const childLi = document.createElement('li');
            const childSlugClass = childSlug.replace(/[^a-zA-Z0-9-_]/g, '');
            childLi.className = `subspecialty-option ${childSlugClass}`;
            childLi.setAttribute('data-filter', `.${childSlug}`);
            childLi.appendChild(document.createTextNode(childLabel));
            subList.appendChild(childLi);
          } else {
              console.warn("Skipping sub-menu item - missing label or slug:", childItem);
          }
        });

        // Only append sublist if it actually has items
        if (subList.hasChildNodes()) {
            parentLi.appendChild(subList);
        } else {
             console.warn(`Specialty "${parentLabel}" had a sub-menu structure in source, but no valid sub-items found.`);
             // Decide: treat as parent-only or skip? Treating as parent-only for now.
        }

      }
      // Append the created parent LI (with or without its sublist) to the dropdown options
      this.elements.optionsList.appendChild(parentLi);

    }); // End forEach main specialty item
  }


  // --- Interaction Logic (from previous refactor - mostly unchanged) ---

  addEventListeners() {
        console.log(this.elements,'elements');
    // Prevent errors if elements were not found in constructor
    if (!this.elements.trigger || !this.elements.wrapper || !this.elements.menu || !this.elements.optionsList ) {
        console.error("Cannot add event listeners - essential elements missing.");
        return;
    }


    
    // --- Toggle Dropdown on Trigger Click ---
    this.elements.trigger.addEventListener('click', (e) => {

      console.log('trigger clicked');
      
      e.stopPropagation();
      this.toggleDropdown();
    });
    this.elements.wrapper.addEventListener('click', (e) => {
        if (e.target !== this.elements.trigger && !this.elements.menu.contains(e.target)) {
            this.toggleDropdown();
        }
    });

    // --- Close Dropdown on Click Outside ---
    document.addEventListener('click', (e) => {
      if (!this.elements.menu.classList.contains('hidden') && !this.elements.wrapper.contains(e.target)) {
        this.toggleDropdown(false);
      }
    });

    // --- Handle Option Selection ---
    this.elements.optionsList.addEventListener('click', (e) => {
        const targetLi = e.target.closest('li');
        // Ensure the click was on an LI *directly* under optionsList or a subspecialty-list
        if (targetLi && (this.elements.optionsList.contains(targetLi) || targetLi.closest('.subspecialty-list'))) {
            // Prevent selecting the parent LI if a sub-LI was clicked (optional, depends on desired UX)
            if (e.target.closest('.subspecialty-option')) {
                 this.selectOption(e.target.closest('.subspecialty-option'));
            } else if (targetLi.classList.contains('specialty-option') || targetLi.classList.contains('all-specialties')) {
                 this.selectOption(targetLi);
            }
        }
    });


    
  }

  toggleDropdown(forceShow = null) {
    if (!this.elements.menu) return; // Element check

    const currentlyHidden = this.elements.menu.classList.contains('hidden');
    const show = forceShow !== null ? forceShow : currentlyHidden;

    if (show) {
      this.elements.menu.classList.remove('hidden');
      this.elements.arrow?.classList.add('active');
    } else {
      this.elements.menu.classList.add('hidden');
      this.elements.arrow?.classList.remove('active');
      // Reset filter when closing only if input exists
      if(this.elements.input) {
          this.elements.input.value = '';
          this.filterOptions('');
      }
    }
  }

  selectOption(optionElement) {
    if (!optionElement || !this.elements.trigger || !this.elements.allOptions) return; // Element check

    const label = optionElement.firstChild.textContent.trim(); // Get text, ignoring sub-list
    const filterValue = optionElement.getAttribute('data-filter');

    this.elements.trigger.textContent = label;

    // Update Active Class
    this.elements.allOptions.forEach(opt => opt.classList.remove('active'));
    optionElement.classList.add('active');

     const parentLi = optionElement.closest('.specialty-option');
     if (parentLi && parentLi !== optionElement && !parentLi.classList.contains('all-specialties')) {
        // Maybe add a general 'parent-active' class for styling if needed
        // parentLi.classList.add('parent-active');
     }

    this.selectedFilter = filterValue;
    this.toggleDropdown(false);

    // --- Trigger filtering logic here ---
    console.log(`Selected: ${label}, Filter: ${filterValue}`);
    // Example: Dispatch an event for other parts of your code (like Isotope) to listen to
     this.container.dispatchEvent(new CustomEvent('specialtyFilterChanged', {
        bubbles: true, // Allow event to bubble up
        detail: {
            filter: filterValue,
            label: label
         }
     }));
  }

filterOptions(searchText) {
  if (!this.elements.mainOptions || !this.elements.input) return;

  const filterText = searchText.toLowerCase().trim();

  this.elements.mainOptions.forEach(mainOption => {
    const mainLabel = mainOption.firstChild?.textContent?.toLowerCase().trim() || '';

    const subspecialtyList = mainOption.querySelector('.subspecialty-list');

    if (mainLabel.includes(filterText) || filterText === '') {
      mainOption.classList.remove('filtered-out');

      if (subspecialtyList) {
        subspecialtyList.style.display = 'block'; // Always show children of visible parents
        subspecialtyList.querySelectorAll('li').forEach(sub => {
          sub.style.display = ''; // Ensure all subspecialties are visible
        });
      }
    } else {
      mainOption.classList.add('filtered-out');
    }

    // Handle the "All Specialties" item separately if needed
    if (mainOption.classList.contains('all-specialties')) {
      if (mainLabel.includes(filterText) || filterText === '') {
        mainOption.classList.remove('filtered-out');
      } else {
        mainOption.classList.add('filtered-out');
      }
    }
  });
}


}

 

export default SpecialtyDropdown; // If using modules